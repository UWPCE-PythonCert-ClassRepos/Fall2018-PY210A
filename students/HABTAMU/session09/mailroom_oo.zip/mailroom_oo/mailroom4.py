# mailroom_oo.py

class Donor:
    name = ""
    donations = []

    def __init__(self, name,contribution=None):
        self.donations.append(contribution)

    def get_donor():

    def add_donations(self, donations):
        self.donations.append(donations)

    def get_total_contribution():

    
    def get_


    @property
    def num_donations(self):
        return len(self.donations)


    def get_donors_db():
        donors = {
            'Bill Gates' : [500,200,300],
            'Bil Gtes': [500, 200, 300],
            'Bl tes': [500, 200, 300]
        }
        return donors


