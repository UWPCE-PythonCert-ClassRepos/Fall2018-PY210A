# test mailroom

import os
from donor_models import Donor DonorCollecion


def test_create_donor():
    donor = Donor("Fred Flinstone")
    donor.add_donation(500)

    assert donor.name == "Fred Flinstone"


def test_add_donation():
    donor = Donor("Fred Flinstone")

    donor.add_donations(500)
    assert donor.num_donations == 1
    
def test_Donor_thank_you_Letter():
    pass


def test_donor_collection():
    dc = DonorCollecion()
    dc.add_donor(Donor("Bob"))
    dc.find_donor()
    dc.list_donors()
    dc.thank_donor()
    dc.create_report()